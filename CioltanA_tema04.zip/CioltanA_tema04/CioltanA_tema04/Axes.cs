﻿using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace CioltanA_tema04
{
    // Clasa care deseneaza axele de coordonate 3D
    class Axes
    {
        private bool visibility;
        private const int AXE_LENGTH = 100;

        // Constructor
        public Axes()
        {
            visibility = true;
        }

        // Deseneaza axele OX, OY, OZ
        public void Draw()
        {
            if (visibility)
            {
                GL.Begin(PrimitiveType.Lines);

                //OX
                GL.Color3(Color.Red);
                GL.Vertex3(0, 0, 0);
                GL.Vertex3(AXE_LENGTH, 0, 0);

                //OY
                GL.Color3(Color.Blue);
                GL.Vertex3(0, 0, 0);
                GL.Vertex3(0, AXE_LENGTH, 0);

                //OZ
                GL.Color3(Color.Yellow);
                GL.Vertex3(0, 0, 0);
                GL.Vertex3(0, 0, AXE_LENGTH);

                GL.End();
            }
        }

        // Afiseaza axele
        public void Show()
        {
            visibility = true;
        }

        // Ascunde axele
        public void Hide()
        {
            visibility = false;
        }

        // Comuta vizibilitatea
        public void ToogleVisibility()
        {
            visibility = !visibility;
        }
    }
}
