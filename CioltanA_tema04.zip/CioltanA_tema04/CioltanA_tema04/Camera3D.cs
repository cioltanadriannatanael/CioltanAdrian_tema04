﻿//Cioltan Adrian-Natanael, grupa 3134B
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;

namespace CioltanA_tema04
{
    // Clasa care gestionează pozitia si miscarea camerei 3D
    class Camera3D
    {
        private Vector3 eye;
        private Vector3 target;
        private Vector3 up_vector;

        private const float MOVEMENT_UNIT = 0.01f;
        // Constructor implicit
        public Camera3D()
        {
            eye = new Vector3(70, 70, 70);
            target = new Vector3(0, 0, 0);
            up_vector = new Vector3(0, 1, 0);
        }
        // Constructor cu parametri int
        public Camera3D(int _eyeX, int _eyeY, int _eyeZ, int _targetX, int _targetY, int _targetZ, int _upX, int _upY, int _upZ)
        {
            eye = new Vector3(_eyeX, _eyeY, _eyeZ);
            target = new Vector3(_targetX, _targetY, _targetZ);
            up_vector = new Vector3(_upX, _upY, _upZ);
        }
        // Constructor cu parametri Vector3
        public Camera3D(Vector3 _eye, Vector3 _target, Vector3 _up)
        {
            eye = _eye;
            target = _target;
            up_vector = _up;
        }
        // Seteaza matricea camerei
        public void SetCamera()
        {
            Matrix4 camera = Matrix4.LookAt(eye, target, up_vector);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref camera);
        }
        // Miscare la dreapta
        public void MoveRight()
        {
            eye = new Vector3(eye.X, eye.Y, eye.Z - MOVEMENT_UNIT);
            target = new Vector3(target.X, target.Y, target.Z - MOVEMENT_UNIT);
            SetCamera();
            Console.WriteLine();
        }
        // Miscare la stanga
        public void MoveLeft()
        {
            eye = new Vector3(eye.X, eye.Y, eye.Z + MOVEMENT_UNIT);
            target = new Vector3(target.X, target.Y, target.Z + MOVEMENT_UNIT);
            SetCamera();
            Console.WriteLine();
        }
        // Miscare înainte
        public void MoveForward()
        {
            eye = new Vector3(eye.X - MOVEMENT_UNIT, eye.Y, eye.Z);
            target = new Vector3(target.X - MOVEMENT_UNIT, target.Y, target.Z);
            SetCamera();
            Console.WriteLine();
        }
        // Miscare înapoi
        public void MoveBackward()
        {
            eye = new Vector3(eye.X + MOVEMENT_UNIT, eye.Y, eye.Z);
            target = new Vector3(target.X + MOVEMENT_UNIT, target.Y, target.Z);
            SetCamera();
            Console.WriteLine();
        }
        // Miscare în sus
        public void MoveUp()
        {
            eye = new Vector3(eye.X, eye.Y + MOVEMENT_UNIT, eye.Z);
            target = new Vector3(target.X, target.Y + MOVEMENT_UNIT, target.Z);
            SetCamera();
            Console.WriteLine();
        }
        // Miscare în jos
        public void MoveDown()
        {
            eye = new Vector3(eye.X, eye.Y - MOVEMENT_UNIT, eye.Z);
            target = new Vector3(target.X, target.Y - MOVEMENT_UNIT, target.Z);
            SetCamera();
            Console.WriteLine();
        }
        // Pozitioneaza camera aproape
        public void Near()
        {
            eye = new Vector3(200, 175, 25);
            target = new Vector3(0, 25, 0);
            SetCamera();
            Console.WriteLine();
        }
        // Pozitioneaza camera departe
        public void FarAway()
        {
            eye = new Vector3(400, 175, 225);
            target = new Vector3(0, 25, 0);
            SetCamera();
            Console.WriteLine();
        }

        // Reseteaza camera la valorile implicite
        public void ResetCamera()
        {
            Camera3D defaultCam = new Camera3D();
            Matrix4 camera = Matrix4.LookAt(defaultCam.eye, defaultCam.target, defaultCam.up_vector);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref camera);
        }

    }
}
