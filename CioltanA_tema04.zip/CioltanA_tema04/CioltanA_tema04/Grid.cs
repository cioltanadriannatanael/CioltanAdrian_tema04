﻿using OpenTK.Graphics.OpenGL;
using System.Drawing;

namespace CioltanA_tema04
{
    // Clasa care deseneaza o grila 3D pe planul XY
    class Grid
    {
        private bool visibility;

        private readonly Color GRIDCOLOR = Color.WhiteSmoke;
        private readonly Color colorisation;

        private const int GRIDSTEP = 10;
        private const int UNITS = 50;
        private const int POINT_OFFSET = GRIDSTEP * UNITS;
        private const int MICRO_OFFSET = 1;

        // Constructor
        public Grid()
        {
            colorisation = GRIDCOLOR;
            visibility = true;
        }
        // Afiseaza grila
        public void Show()
        {
            visibility = true;
        }
        // Ascunde grila
        public void Hide()
        {
            visibility = false;
        }
        // Comuta vizibilitatea
        public void ToogleVisibility()
        {
            visibility = !visibility;
        }

        // Schimba culoarea grilei
        public void changeColor(Color newColor)
        {
            GL.Color3(newColor);
        }

        // Deseneaza grila pe planul XZ
        public void Draw()
        {
            if (visibility)
            {
                GL.Begin(PrimitiveType.Lines);
                GL.Color3(colorisation);

                for (int i = -1 * GRIDSTEP * UNITS; i <= GRIDSTEP * UNITS; i += GRIDSTEP)
                {
                    GL.Vertex3(i + MICRO_OFFSET, 0, POINT_OFFSET);
                    GL.Vertex3(i + MICRO_OFFSET, 0, -1 * POINT_OFFSET);

                    GL.Vertex3(POINT_OFFSET, 0, i + MICRO_OFFSET);
                    GL.Vertex3(-1 * POINT_OFFSET, 0, i + MICRO_OFFSET);
                }
                GL.End();
            }
        }
    }
}
