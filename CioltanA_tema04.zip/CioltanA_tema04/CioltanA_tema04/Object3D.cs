﻿using CioltanA_tema04;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace CioltanA_tema04
{
    class Object3D
    {
        private bool visibility;
        private Randomizer rnd;
        private string objFileName;
        private const int FACTOR_SCALARE_IMPORT = 100;

        private List<Vector3> vertexPoints;
        private Color color;

        private int sizeOffset;
        private int heighOffset;
        private int radialOffset;

        private Color meshColor;
        private bool hasError;

        // Constructorul clasei Object3D - initializează un obiect 3D
        public Object3D()
        {
            rnd = new Randomizer();

            visibility = true;

            vertexPoints = new List<Vector3>();


            sizeOffset = rnd.RandomInt(1, 3);
            heighOffset = rnd.RandomInt(0, 10);
            radialOffset = rnd.RandomInt(0, 30);

            color = rnd.RandomColor(); ;

            this.ReadVerticesFromFile();


            //To load from obj file uncomment:
            //this.LoadObject(rnd.RandomColor());
        }

        // Funcție pentru citirea vertecșilor din fișierul CubeVertex.txt
        public void ReadVerticesFromFile()
        {
            int j = 0;
            string path = Directory.GetCurrentDirectory() + "\\CubeVertex.txt";
            StreamReader reader = null;


            try
            {
                reader = new StreamReader(path);
                if (reader != null)
                {
                    while (!reader.EndOfStream)
                    {
                        string[] data = reader.ReadLine().Split(',');
                        vertexPoints.Add(new Vector3(Convert.ToInt32(data[0]) * sizeOffset + radialOffset,
                            Convert.ToInt32(data[1]) + heighOffset,
                            Convert.ToInt32(data[2]) * sizeOffset + radialOffset));
                    }
                }
                else
                {
                    Console.WriteLine("Error null reference to a file !!!");
                }
            }
            catch
            {
                Console.WriteLine("Error opening file !!!");
            }
        }

        // Funcție pentru afișarea obiectului
        public void Show()
        {
            visibility = true;
        }

        // Funcție pentru ascunderea obiectului
        public void Hide()
        {
            visibility = false;
        }

        // Funcție pentru comutarea vizibilității obiectului
        public void ToogleVisibility()
        {
            visibility = !visibility;
        }

        // Funcție pentru desenarea obiectului în scenă
        public void Draw()
        {
            if (visibility)
            {
                GL.Begin(PrimitiveType.Triangles);
                for (int i = 0; i < vertexPoints.Count; i++)
                {
                    GL.Color3(color);
                    GL.Vertex3(vertexPoints[i]);
                }
                GL.End();
            }
        }

        // Funcție care verifică dacă obiectul a atins solul
        public bool onGround()
        {
            for (int i = 0; i < vertexPoints.Count; i++)
            {
                if (vertexPoints[i].Y <= 0)
                {
                    return true;
                }
            }

            return false;
        }

        // Funcție pentru simularea căderii obiectului
        public void FallObject()
        {
            int downSpeed = rnd.RandomInt(0, 5);

            if (!onGround() && visibility)
            {
                for (int i = 0; i < vertexPoints.Count; i++)
                {
                    vertexPoints[i] = new Vector3(vertexPoints[i].X, vertexPoints[i].Y - downSpeed, vertexPoints[i].Z);
                }
            }

        }

        // Funcție privată pentru încărcarea vertecșilor din fișier .obj
        private List<Vector3> LoadFromObjFile(string fname)
        {
            List<Vector3> vlc3 = new List<Vector3>();

            var lines = File.ReadLines(fname);
            foreach (var line in lines)
            {
                if (line.Trim().Length > 2)
                {
                    string ch1 = line.Trim().Substring(0, 1);
                    string ch2 = line.Trim().Substring(1, 1);
                    if (ch1 == "v" && ch2 == " ")
                    {

                        string[] block = line.Trim().Split(' ');
                        if (block.Length == 4)
                        {
                            // ATENTIE: Pericol!!!
                            float xval = float.Parse(block[1].Trim()) * FACTOR_SCALARE_IMPORT;
                            float yval = float.Parse(block[2].Trim()) * FACTOR_SCALARE_IMPORT;
                            float zval = float.Parse(block[3].Trim()) * FACTOR_SCALARE_IMPORT;

                            vlc3.Add(new Vector3((int)xval, (int)yval, (int)zval));

                        }
                    }
                }
            }

            return vlc3;
        }

        // Funcție pentru încărcarea unui obiect 3D din fișier .obj
        public void LoadObject(Color col)
        {
            objFileName = Directory.GetCurrentDirectory() + "\\soccer_ball.obj";
            try
            {
                vertexPoints = LoadFromObjFile(objFileName);

                if (vertexPoints.Count == 0)
                {
                    Console.WriteLine("Crearea obiectului a esuat: obiect negasit/coordonate lipsa!");
                    return;
                }
                visibility = false;
                meshColor = col;
                hasError = false;
                Console.WriteLine("Obiect 3D încarcat - " + vertexPoints.Count.ToString() + " vertexuri disponibile!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: assets file <" + objFileName + "> is missing!!!");
                hasError = true;
            }
        }
    }
}