﻿using CioltanA_tema04;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CioltanA_tema04
{
    // Clasa principala a programului

    class Program
    {
        // Punctul de intrare in aplicatie

        static void Main(string[] args)
        {
            using (Window3D window = new Window3D())
            {
                window.Run(0.0, 30.0); // Ruleaza fereastra 3D cu 30 cadre pe secunda
            }
        }
    }
}
