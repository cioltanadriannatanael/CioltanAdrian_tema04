﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CioltanA_tema04
{
    // Clasa care genereaza culori aleatorii
    class Randomizer
    {
        private Random rnd;

        // Constructor
        public Randomizer()
        {
            rnd = new Random();
        }

        // Returneaza o culoare aleatorie
        public Color RandomColor()
        {
            Color color = Color.FromArgb(rnd.Next(1, 256), rnd.Next(1, 256), rnd.Next(1, 256));

            return color;
        }

        public int RandomInt(int minVal, int maxVal)
        {
            return rnd.Next(minVal, maxVal);
        }
    }
}
