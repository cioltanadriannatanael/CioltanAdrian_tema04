﻿using CioltanA_tema04;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CioltanA_tema04
{
    // Clasa principala a ferestrei 3D (extinde GameWindow)
    class Window3D : GameWindow
    {
        private Randomizer rnd;
        private KeyboardState lastKeyboard;
        private MouseState lastMouse;
        private Randomizer rando;
        private Axes axe;
        private Grid grid;
        private Camera3D cam;
        private List<Object3D> cubesList;
        private ulong updatesCounter;
        private ulong framesCounter;
        private bool displayMarker;

        private readonly Color BACKGROUND_COLOR = Color.DarkSlateGray;
        // Constructorul ferestrei
        public Window3D() : base(800, 600, new OpenTK.Graphics.GraphicsMode(32, 24, 0, 8))
        {
            VSync = VSyncMode.On;

            rando = new Randomizer();
            cam = new Camera3D();
            cubesList = new List<Object3D>();
            axe = new Axes();
            grid = new Grid();
            rnd = new Randomizer();


            displayMarker = false;
            updatesCounter = 0;
            framesCounter = 0;

            HelpMenu();
        }

        // Initializare la pornire
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            GL.Enable(EnableCap.DepthTest);
            GL.DepthFunc(DepthFunction.Less);

            GL.Hint(HintTarget.PolygonSmoothHint, HintMode.Nicest);
        }
        // Redimensionare fereastra
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            updatesCounter++;

            GL.ClearColor(BACKGROUND_COLOR);

            GL.Viewport(0, 0, this.Width, this.Height);

            Matrix4 perspective = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, (float)this.Width / (float)this.Height, 1, 1024);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref perspective);

            cam.SetCamera();
        }
        // Actualizare logica (input tastatura)
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            KeyboardState currentKeyboard = Keyboard.GetState();
            MouseState currentMouse = Mouse.GetState();

            if (displayMarker)
            {
                TimeStampIt("update", updatesCounter.ToString());

            }
            // Inchide aplicatia
            if (currentKeyboard[Key.Escape])
            {
                Exit();
            }

            // Resetare camera și fundal
            if (currentKeyboard[Key.R])
            {
                cam.ResetCamera();
                GL.ClearColor(BACKGROUND_COLOR);
            }

            // Schimba culoarea fundalului
            if (currentKeyboard[Key.B])
            {
                GL.ClearColor(rnd.RandomColor());
            }
            // Comuta vizibilitatea grilei
            if (currentKeyboard[Key.O] && !lastKeyboard.Equals(currentKeyboard))
            {
                foreach (Object3D c in cubesList)
                {
                    c.ToogleVisibility();
                }
            }

            if (currentKeyboard[Key.K] && !lastKeyboard.Equals(currentKeyboard))
            {
                grid.ToogleVisibility();
            }

            if (currentKeyboard[Key.M] && !lastKeyboard.Equals(currentKeyboard))
            {
                axe.ToogleVisibility();
            }


            //camera movement
            if (currentKeyboard[Key.W])
            {
                cam.MoveForward();
            }

            if (currentKeyboard[Key.A])
            {
                cam.MoveLeft();
            }

            if (currentKeyboard[Key.S])
            {
                cam.MoveBackward();
            }

            if (currentKeyboard[Key.D])
            {
                cam.MoveRight();
            }

            if (currentKeyboard[Key.Q])
            {
                cam.MoveUp();
            }

            if (currentKeyboard[Key.E])
            {
                cam.MoveDown();
            }

            if (currentKeyboard[Key.N] && !lastKeyboard.Equals(currentKeyboard))
            {
                cam.Near();
            }

            if (currentKeyboard[Key.F] && !lastKeyboard.Equals(currentKeyboard))
            {
                cam.FarAway();
            }
            // Afiseaza meniul de ajutor
            if (currentKeyboard[Key.H] && !lastKeyboard.Equals(currentKeyboard))
            {
                HelpMenu();
            }

            //object controll
            if (currentMouse[MouseButton.Left] && !lastMouse.Equals(currentMouse))
            {
                cubesList.Add(new Object3D());
            }

            if (currentMouse[MouseButton.Right] && !lastMouse.Equals(currentMouse))
            {
                cubesList.Clear();
            }

            lastKeyboard = currentKeyboard;
            lastMouse = currentMouse;

        }
        // Randare scena
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);
            framesCounter++;

            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.Clear(ClearBufferMask.DepthBufferBit);

            grid.Draw();
            axe.Draw();

            foreach (Object3D c in cubesList)
            {
                c.Draw();
            }

            foreach (Object3D c in cubesList)
            {
                c.FallObject();
            }

            SwapBuffers();
        }
        // Afiseaza meniul in consola
        public void HelpMenu()
        {
            Console.Clear();

            Console.WriteLine("===== MENU =====\n" +
                "(H) - meniu\n" +
                "(W,A,S,D,Q,E) - deplasare camera (izometric)\n" +
                "(ESC) - parasire program\n" +
                "(M) - schimbare vizibilitate sistem de axe\n" +
                "(K) - schimbare vizibilitate grid\n" +
                "(B) - schimbare culoare de fundal\n" +
                "(R) - reseteaza scena la valorile implicite\n" +
                "(LEFT-CLICK) - genereaza un cub\n" +
                "(RIGHT-CLICK) - curata mapa\n");

        }
        // Afiseaza timestamp pentru 
        private void TimeStampIt(String source, String counter)
        {
            String dt = DateTime.Now.ToString("hh:mm:ss.ffff");
            Console.WriteLine("     TSTAMP from <" + source + "> on iteration <" + counter + ">: " + dt);
        }


    }
}
